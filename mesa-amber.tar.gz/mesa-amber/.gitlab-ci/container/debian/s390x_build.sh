#!/bin/bash

arch=s390x

. .gitlab-ci/container/cross_build.sh
